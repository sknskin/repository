package com.demoweb.dto;

import lombok.Data;

@Data
public class RoleDto {

	private int roleNo;
	private String roleName;
	
}
