package com.springexample.springioc;

public interface TimeService {

	String getTimeString();

}