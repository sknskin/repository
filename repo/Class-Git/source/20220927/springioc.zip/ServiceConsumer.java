package com.springexample.springioc;

public interface ServiceConsumer {

	void doSomething();

}